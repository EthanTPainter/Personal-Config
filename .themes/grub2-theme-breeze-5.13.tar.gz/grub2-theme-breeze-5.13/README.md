# Breeze
A minimalistic GRUB theme inspired by Breeze

![Default view](preview.png)
![Available distro logos](https://cn.pling.com/img//hive/content-pre3/171217-3.png)

## Installation
Copy the "breeze" folder to the themes directory in /boot. If you don't know how to do it, just run the included "install.sh" script as root.
